#!/usr/bin/env python
from __future__ import division
import sys
import tempfile
import argparse
import time
import os
import os.path
import gzip
import re

def get_data( f, g, ma_L, platform="ma", column=1 ):
	"""
	create a dictionary that maps feature IDs to expression values
	"""
	unwanted = [ '#' ]
	
	if platform == "ma": index = 2
	elif platform == "hts": index = 1
	
	names_L = list()
	genes_L = list()
	
	row_count = 0
	for row in f:
		if row[0] in unwanted: continue
		L = row.strip().split( '\t' )
		
		if (row[0] == 'p' or row[0] == 'g') and row_count == 0:
			names_L = L[index:]
			if platform == "ma":
				print >> g, "\t".join( [ L[0], L[column] ] + ma_L )
			elif platform == "hts":
				print >> g, "\t".join( [ L[0] ] + ma_L )
			row_count += 1
			continue
		elif row[0] != 'p' and row[0] != 'g' and row_count == 0:
		  print >> sys.stderr, "Error: missing header in HTS/microarray data file. Please amend and retry."
		  sys.exit( 1 )

		expr_D = dict( zip( names_L, L[index:] ) )
		
		if platform == "ma":
			print >> g, "\t".join( [ L[0], L[column] ] + [ expr_D[k] for k in ma_L ] )
		elif platform == "hts":
			print >> g, "\t".join( [ L[0] ] + [ expr_D[k] for k in ma_L ] )
			genes_L += [ L[0] ]
		row_count += 1
	
	if platform == "ma": return
	elif platform == "hts": return genes_L

def get_sample_names( f ):
	"""
	process the file 'samples.txt' to extract sample names
	"""
	train_hts_L = list()
	test_hts_L = list()
	train_ma_L = list()
	test_ma_L = list()
	
	# file should have two columns

	row_count = 0
	for row in f:
		L = row.strip().split( '\t' )
		if row[0] == 'h' and row_count == 0: # skip the header
			row_count += 1
			continue
		elif row[0] != 'h' and row_count == 0:
		  print >> sys.stderr, "Error: missing header in sample names file. Please add a header 'hts<tab>ma'."
		  sys.exit( 1 )
		if L[0] == "NA":
			test_ma_L += [L[1]]
		elif L[0][0] == '*':
			test_hts_L += [L[0].lstrip( '*' )]
			test_ma_L += [L[1]]
		else:
			train_hts_L += [L[0]]
			train_ma_L += [L[1]]
		row_count += 1
	
	return train_hts_L, test_hts_L, train_ma_L, test_ma_L

def make_data( f, g_f, g2ps_D, design="train", ofn="_data.txt.gz", waste=True ):
	"""
	take raw data and create training and test data
	f - ma data
	g_f - hts data
	g2ps_D - map of gene to probesets
	"""
	unwanted = [ '#' ]
	no_samples = 0
	
	# some stats
	no_genes = 0
	no_genes_included = 0
	no_probesets = 0
	no_probesets_included = 0
	no_probes = 0
	
	# waste: a file to dump all genes without probesets and probesets without intensities
	w1 = gzip.open( design + "_genes_missing.txt.gz", 'wb' )
	w2 = gzip.open( design + "_probesets_missing.txt.gz", 'wb' )
	
	# put the probe data into a hash table
	ps2int = dict()
	for row in f:
		if row[0] in unwanted: continue
		L = row.strip().split( '\t' )
		if row[0] == 'p':
			sample_names = L[2:]
			continue
		ps = int(L[1])
		p = L[0]
		if no_samples == 0:
			no_samples = len( L[2:] )
	
		ints = ",".join( L[2:] )
	
		if ps not in ps2int: # ps are unique
			ps2int[ps] = dict()
	
		ps2int[ps][p] = ints
	
	# put the hts data into a hash table
	rs_data = dict()
	for row in g_f:
		if row[0] == 'g': continue
		L = row.strip().split( '\t' )
		rs_data[ L[0] ] = ",".join( L[1:] )

	# combine the data into a pack
	h = gzip.open( design + ofn, 'wb' )
	
	c = 0
	for g in g2ps_D:
		no_genes += 1
		if c > 100: break
	
		# get the RNA-Seq values
		try:
			rs = rs_data[g]
		except KeyError:
			print >> w1, g
			continue
		no_genes_included += 1
			
		# get probe intensities
		probes = ""
		intensities = ""
		for ps in g2ps_D[g]:
			no_probesets += 1
			try:
				probe_ids = ps2int[ps].keys()
			except KeyError:
				print >> w2, ps
				continue
			no_probesets_included += 1
			for p in probe_ids:
				no_probes += 1
				if probes == '':
					probes = p
					intensities = ps2int[ps][p]
				else:
					probes += "," + p
					intensities += "," + ps2int[ps][p]

		if probes == "":
			print >> h, "\t".join( [ g, str( no_samples ), "0", "NA", rs, "NA" ] )
		else:
			print >> h, "\t".join( [ g, str( no_samples ), str( len( probes.split( ',' )) ), probes, rs, intensities ] )
		c += 0
	
	h.close()
	
	return no_genes, no_genes_included, no_probesets, no_probesets_included, no_probes


def get_gene_to_ps( f ):
	"""
	create a dictionary of gene to probesets
	"""
	g2ps_D = dict()
	for row in f:
		if row[0] == 'g' or row[:2] == "En":
			continue
		L = row.strip().split( '\t' )
		if len( L ) == 1:
			continue
		if L[1] == '.':
			continue
		g = L[0]; ps = int( L[1] )
		if g not in g2ps_D:
			g2ps_D[g] = set([ps])
		else:
			g2ps_D[g].add(ps)
	
	return g2ps_D

"""
TODO
- thorough validation of data_ids.txt
- include error checks
- output the genes that were excluded (plus why the were excluded)
- check that the headers are labelled correctly

"""

if __name__ == '__main__':
	unwanted = [ '#' ]
	
	# initialise the parser
	parser = argparse.ArgumentParser( description="Produce training and testing data for MaLTE gene expression models." )
	
	# build the options
	parser.add_argument( '-s', "--samples", default="samples.txt", help="the name of the file containing the map of sample names between HTS and microarray [default: samples.txt]" )
	parser.add_argument( '-t', "--hts-data", default="hts_data.txt", help="the name of the file containing a matrix of HTS expression estimates [default: hts_data.txt]" )
	parser.add_argument( '-m', "--ma-data", default="ma_data.txt", help="the name of the file containing a matrix of microarray probe intensities [default: ma_data.txt]" )
	parser.add_argument( '-g', "--gene-probesets", default="gene_probesets.txt", help="the name of the file containig the map of gene names to probeset names [default: gene_probesets.txt]" )
	parser.add_argument( '-r', "--raw", action='store_true', default=False, help="should you used output directly from APT apt-cel-extract? [default: False]" )
	
	# if no args given
	if len( sys.argv ) == 1:
		print >> sys.stderr, "Error: missing input files."
		sys.exit( 1 )
	
	# build vars
	args = parser.parse_args()
	id_fn = args.samples
	ma_fn = args.ma_data
	hts_fn = args.hts_data
	g2ps_fn = args.gene_probesets
	raw = args.raw
	
	# check if the files exist
	if os.path.exists( id_fn ): pass
	else:
	  print >> sys.stderr, "Error: Missing sample names file (e.g. samples.txt)."
	  sys.exit( 1 )
	
	if os.path.exists( ma_fn ): pass
	else:
	  print >> sys.stderr, "Error: Missing probe intensity file (e.g. ma_data.txt or raw_ma_data.txt)."
	  sys.exit( 1 )	
	
	if os.path.exists( hts_fn ): pass
	else:
	  print >> sys.stderr, "Error: Missing HTS data file (e.g. hts_data.txt)."
	  sys.exit( 1 )		
	
	if os.path.exists( g2ps_fn ): pass
	else:
	  print >> sys.stderr, "Error: Missing gene-to-probe set file (e.g. gene_probesets.txt)."
	  sys.exit( 1 )
	
	# raw microarray file (direct from APT)?
	if raw:
		column = 4
	else:
		column = 1
	
	# raise an error if the named directory already exists
	try:
		os.mkdir( "temp" )
	except OSError:
	  print >> sys.stderr, "Warning: Found directory 'temp'. Overwriting..."

	# get sample names
	if re.search( r"gz$", id_fn ):
		f = gzip.open( id_fn )
	elif re.search( r"txt$", id_fn ):
		f = open( id_fn )
	else:
		print >> sys.stderr, "Error: Invalid input file '%s': should be .txt or .gz text file." % id_fn
		sys.exit( 1 )
	train_hts_L, test_hts_L, train_ma_L, test_ma_L = get_sample_names( f )
	f.close()
	
	# get map of genes to ps
	print >> sys.stderr, "Creating a map of genes to probe sets from '%s'..." % g2ps_fn,
	if re.search( r"gz$", g2ps_fn ):
		f = gzip.open( g2ps_fn )
	elif re.search( r"txt$", g2ps_fn ):
		f = open( g2ps_fn )
	else:
		print >> sys.stderr, "Error: Invalid input file '%s': should be .txt or .gz text file." % g2ps_fn
		sys.exit( 1 )
	g2ps_D = get_gene_to_ps( f )
	f.close()
	print >> sys.stderr, "OK"

	# create the training probe data
	if re.search( r"gz$", ma_fn ):
		f = gzip.open( ma_fn )
	elif re.search( r"txt$", ma_fn ):
		f = open( ma_fn )
	else:
		print >> sys.stderr, "Error: Invalid input file '%s': should be .txt or .gz text file." % ma_fn
		sys.exit( 1 )
	
	print >> sys.stderr, "Extracting training microarray data...",
	g_train_ma_f = tempfile.TemporaryFile( dir="temp" )
	get_data( f, g_train_ma_f, train_ma_L, platform="ma", column=column )
	print >> sys.stderr, "OK"

	# create the testing probe data
	f.seek( 0 )
	
	print >> sys.stderr, "Extracting testing microarray data...",
	g_test_ma_f = tempfile.TemporaryFile( dir="temp" )
	get_data( f, g_test_ma_f, test_ma_L, platform="ma", column=column )
	print >> sys.stderr, "OK"

	f.close()

	# create the training hts data
	if re.search( r"gz$", hts_fn ):
		f = gzip.open( hts_fn )
	elif re.search( r"txt$", hts_fn ):
		f = open( hts_fn )
	else:
		print >> sys.stderr, "Error: Invalid input file '%s': should be .txt or .gz text file." % hts_fn
		sys.exit( 1 )

	print >> sys.stderr, "Extracting training HTS data...",
	g_train_hts_f = tempfile.TemporaryFile( dir="temp" )
	genes_L = get_data( f, g_train_hts_f, train_hts_L, platform="hts" )
	print >> sys.stderr, "OK"
	
	# create the testing hts data
	f.seek( 0 )
	
	print >> sys.stderr, "Extracting testing HTS data...",
	g_test_hts_f = tempfile.TemporaryFile( dir="temp" )
	if len( test_hts_L ) == 0:
		print >> sys.stderr, "NOT REQUIRED"
		# create some dummy data
		print >> g_test_hts_f, "gene_id\tsamples"		
		for k in genes_L: print >> g_test_hts_f, "%s\tNA" % k
	else:
		get_data( f, g_test_hts_f, test_hts_L, platform="hts" )
		print >> sys.stderr, "OK"
	
	f.close()
	
	# rewind the file handles
	g_train_ma_f.seek( 0 )
	g_test_ma_f.seek( 0 )
	g_train_hts_f.seek( 0 )
	g_test_hts_f.seek( 0 )

	# combine training data
	print >> sys.stderr, "Compiling training data...",
	tr_genes_i, tr_genes_present_i, tr_probesets_i, tr_probesets_present_i, tr_probes_i = make_data( g_train_ma_f, g_train_hts_f, g2ps_D, design="train", waste=True )
	print >> sys.stderr, "DONE"

	# combine testing data
	print >> sys.stderr, "Compiling testing data...",
	te_genes_i, te_genes_present_i, te_probesets_i, te_probesets_present_i, te_probes_i = make_data( g_test_ma_f, g_test_hts_f, g2ps_D, design="test", waste=True )
	print >> sys.stderr, "DONE"
	
	print >> sys.stderr
	print >> sys.stderr, "Stats: Training data"
	print >> sys.stderr, "Total number of genes     = %s" % tr_genes_i
	print >> sys.stderr, "Total genes included      = %s" % tr_genes_present_i
	print >> sys.stderr, "Total number of probesets = %s" % tr_probesets_i
	print >> sys.stderr, "Total probesets included  = %s" % tr_probesets_present_i
	print >> sys.stderr, "Total number of probes    = %s" % tr_probes_i
	print >> sys.stderr
	print >> sys.stderr, "Stats: Testing data"
	print >> sys.stderr, "Total number of genes     = %s" % te_genes_i
	print >> sys.stderr, "Total genes included      = %s" % te_genes_present_i
	print >> sys.stderr, "Total number of probesets = %s" % te_probesets_i
	print >> sys.stderr, "Total probesets included  = %s" % te_probesets_present_i
	print >> sys.stderr, "Total number of probes    = %s"	% te_probes_i

	# clean up
	g_train_ma_f.close()
	g_test_ma_f.close()
	g_train_hts_f.close()
	g_test_hts_f.close()
	
	print >> sys.stderr, "Cleaning up...",
	os.rmdir( "temp" )
	#os.chdir( ".." )
	print >> sys.stderr, "DONE"
	
	# return exit success
	sys.exit( 0 )
