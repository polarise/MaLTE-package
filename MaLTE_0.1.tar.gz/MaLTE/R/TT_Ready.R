#-------------------------------------------------------------------------------
#
# Union of classes numeric, logical and matrix
#
#-------------------------------------------------------------------------------
setClassUnion( "numericORlogicalORmatrix", c( "numeric", "logical", "matrix" ))
# hts.test is either numeric or logical hence the class union

setClassUnion( "numericORmatrix", c( "numeric", "matrix" ))
# hts.train is either numeric or logical hence the class union

#-------------------------------------------------------------------------------
#
# TT.Ready Abstract Base Class
#
#-------------------------------------------------------------------------------
setClass( "TT.Ready", representation( gene.id="character", no.train="numeric", no.test="numeric", no.probes="numeric", hts.train="numericORmatrix", hts.test="numericORlogicalORmatrix", probes.train="matrix", probes.test="matrix" ), "VIRTUAL" )

#-------------------------------------------------------------------------------
#
# TT.Ready.Gene Class
#
#-------------------------------------------------------------------------------
setClass( "TT.Ready.Gene", contains="TT.Ready" )

#
# TT.Ready.Gene constructor
#
TT.Ready.Gene <- function( m )
{
	# validations?
	
	# validation that the number of samples, probes etc is consistent
	if ( is.na( m$hts.test )) # ??
		m$hts.test <- NA
	
	object <- new( "TT.Ready.Gene", gene.id=m$gene.id, no.train=m$no.train, no.test=m$no.test, no.probes=m$no.probes, hts.train=m$hts.train, hts.test=m$hts.test, probes.train=m$probes.train, probes.test=m$probes.test )
	return( object )
}

#
# TT.Ready.Gene methods
#
setMethod( "show", signature( object="TT.Ready.Gene" ), function( object )
	{
		cat( "Gene ID :", object@gene.id, "\n" )
		cat( "#Train  :", object@no.train, "\n" )
		cat( "#Test   :", object@no.test, "\n" )
		cat( "#Probes :", object@no.probes, "\n" )
		cat( "HTS-Test?", all( !is.na( object@hts.test )), "\n" ) # FALSE if at least one sample is missing
	}
)

# show.hts.train()
setGeneric( "show.hts.train", function( object ) standardGeneric( "show.hts.train" ))
setMethod( "show.hts.train", signature( object="TT.Ready.Gene" ), function( object )
	{
		cat( "Training HTS data:\n" )
		cat( object@hts.train, "\n" )
	}
)

# show.hts.test()
setGeneric( "show.hts.test", function( object ) standardGeneric( "show.hts.test" ))
setMethod( "show.hts.test", signature( object="TT.Ready.Gene" ), function( object )
	{
		cat( "Test HTS data:\n" )
		cat( object@hts.test, "\n" )
	}
)

# show.probes.train()
setGeneric( "show.probes.train", function( object ) standardGeneric( "show.probes.train" ))
setMethod( "show.probes.train", signature( object="TT.Ready.Gene"), function( object )
	{
		cat( "Training probe data:\n" )
		cat( object@probes.train, "\n" )
	}
)

# show.probes.test()
setGeneric( "show.probes.test", function( object ) standardGeneric( "show.probes.test" ))
setMethod( "show.probes.test", signature( object="TT.Ready.Gene" ), function( object )
	{
		cat( "Test probe data:\n" )
		cat( object@probes.test, "\n" )
	}
)

#setMethod( "summary", ... )

# run()
setGeneric( "run", function( object, params.object, ... ) standardGeneric( "run" ) )
setMethod( "run", signature( object="TT.Ready.Gene" ), function( object, params.object, OOB=FALSE )
	{
		if ( OOB )
			params.object@OOB <- OOB
		tt.seq <- train.and.predict( object, params.object )
		return( tt.seq )	
	}
)

# oob.run()
# alias to run( TT.Ready.Gene, OOB=TRUE )
setGeneric( "oob.run", function( object, params.object ) standardGeneric( "oob.run" ) )
setMethod( "oob.run", signature( object="TT.Ready.Gene" ), function( object, params.object )
	{
		params.object@OOB <- TRUE
		tt.seq.oob <- train.and.predict( object, params.object )
		return( tt.seq.oob )
	}
)

#-------------------------------------------------------------------------------
#
# TT.Ready.Tx Class
#
#-------------------------------------------------------------------------------
setClass( "TT.Ready.Tx", contains="TT.Ready", representation( tx.id="character", no.txs="numeric" ))

TT.Ready.Tx <- function( m )
{
	# validations?
	
	
	object <- new( "TT.Ready.Tx", gene.id=m$gene.id, tx.id=m$tx.id, no.txs=m$no.txs, no.train=m$no.train, no.test=m$no.test, no.probes=m$no.probes, hts.train=m$hts.train, hts.test=m$hts.test, probes.train=m$probes.train, probes.test=m$probes.test )
	return( object )
}

#
# TT.Ready.Tx methods
#

# show()
setMethod( "show", signature( object="TT.Ready.Tx" ), function( object )
	{
		cat( "Gene ID :", object@gene.id, "\n" )
		cat( "Tx ID   :", object@tx.id, "\n" )
		cat( "#Tx     :", object@no.txs, "\n" )
		cat( "#Train  :", object@no.train, "\n" )
		cat( "#Test   :", object@no.test, "\n" )
		cat( "#Probes :", object@no.probes, "\n" )
		cat( "HTS-Test?", all( !is.na( object@hts.test )), "\n" )
	}
)

# show.hts.train()
setMethod( "show.hts.train", signature( object="TT.Ready.Tx" ), function( object )
	{
		cat( "Training HTS data:\n" )
		cat( object@hts.train, "\n" )
	}
)

# show.hts.test()
setMethod( "show.hts.test", signature( object="TT.Ready.Tx" ), function( object )
	{
		cat( "Test HTS data:\n" )
		cat( object@hts.test, "\n" )
	}
)

# show.probes.train()
setMethod( "show.probes.train", signature( object="TT.Ready.Tx"), function( object )
	{
		cat( "Training probe data:\n" )
		cat( object@probes.train, "\n" )
	}
)

# show.probes.test()
setMethod( "show.probes.test", signature( object="TT.Ready.Tx" ), function( object )
	{
		cat( "Test probe data:\n" )
		cat( object@probes.test, "\n" )
	}
)

# run()
setMethod( "run", signature( object="TT.Ready.Tx" ), function( object, params.object, OOB=FALSE )
	{
		if ( OOB )
			params.object@OOB <- OOB
		tt.seq.txs <- train.and.predict.txs( object, params.object )
		return( tt.seq.txs )	
	}
)

# oob.run()
# alias to run( TT.Ready.Tx, OOB=TRUE )
setMethod( "oob.run", signature( object="TT.Ready.Tx" ), function( object, params.object )
	{
		params.object@OOB <- TRUE
		tt.seq.oob.txs <- train.and.predict.txs( object, params.object )
		return( tt.seq.oob.txs )
	}
)
